
package ExceptionHandling;

import java.util.*;
public class TryCatch {
    public static void main(String args[])
    {
        try{
        Scanner sc=new Scanner(System.in);
        int arr[]={1,2,3,4,5};
        
        System.out.print("Enter Index Number :-");
        int index=sc.nextInt();
        System.out.println("Value is "+arr[index]);
        
        }
        catch(Exception e)
        {
//            System.out.println(e);
            System.out.println("Error :- "+e.getMessage());
        }
        System.out.println("Thanks for using our application");
            
    }
}
