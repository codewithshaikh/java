
package Ifelse;

import java.util.*;
public class Switch4 {
    public static void main(String args[])
    {
        
//        Check Positive Negative or Zero using Switch Case
        
        Scanner scan = new Scanner(System.in);
        int a ;
        System.out.println("Enter a Number: ");
        a = scan.nextInt();
        
        switch(Integer.parseInt(Boolean.toString(a>0)))
        {
            case 1:
                System.out.println("Positive Number");
                break;
                
            case 0:
                switch(Integer.parseInt(Boolean.toString(a<0)))
                {
                    case 1:
                        System.out.println("Negative Number");
                        break;
                        
                    case 0:
                        System.out.println("Zero Number");
                        break;
                } 
        }
    }
    
}
