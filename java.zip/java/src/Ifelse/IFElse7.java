package Ifelse;

import java.util.*;
public class IFElse7 {
    
    public static void main(String args[])
    {
        Scanner scan = new Scanner(System.in);
        char alpha;
        System.out.println("Enter Any Alphabet: ");
        alpha = scan.next(".").charAt(0);
        
        if(alpha>='a' && alpha<='z')
        {
            System.out.println("Alphabet is in Lowercase");
        }
        else
        {
            System.out.println("Alphabet is in Uppercase");
        }
    }
    
}


