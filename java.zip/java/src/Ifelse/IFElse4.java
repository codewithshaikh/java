package Ifelse;

import java.util.*;
public class IFElse4 {
    public static void main(String arg[])
    {
        Scanner scan = new Scanner(System.in);
        int a ;
        System.out.println("Enter an Integer: ");
        a = scan.nextInt();
        
        if(a>0)
        {
            System.out.println("Number is Positive");
        }
        else if(a<0)
        {
            System.out.println("Number is Negative");
        }
        else
        {
            System.out.println("Number is Zero");
        }
    }
    
}
