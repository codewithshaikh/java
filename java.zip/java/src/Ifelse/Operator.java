package Ifelse;
    import java.util.*;
/*
a+b
here + is an operator 
a and b are operands

unary operator:- they need only one operand
++(increment operator),--(decrement operator),-(minus)

Binary operator:- they need only two operands.

1)Arithmatic operators :-
    +   -   *    /   %

2)Assignment Opeartors:-
    =   +=  -=  /=  %=

3)Relational operators :- if the relation is true then this operator returns true if the relation is false ten it returns false.
    >   <   >=  <=  ==  !=
    

4)Logical operators :- 

    &&(AND)     ||(OR)      !(NOT)
 */
public class Operator {
    public static void main(String args[])
    {
        int a , b ;
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter the First Value: ");
        a = scan.nextInt();
        
        System.out.println("Enter the Second Value:- ");
        b = scan.nextInt();
        
        System.out.println("Arithmatic Opertors");
        System.out.println("Addition: "+(a+b));
        System.out.println("Subtraction: "+(a-b));
        System.out.println("Multiplication: "+(a*b));
        System.out.println("Division:\nRemainder:"+(a%b)+"\nQuotient:"+(a/b));
        
        System.out.println("\nAssignment OPerators");
        System.out.println("Increments by 2: "+(a+=2));
        System.out.println("Decrements by 2: "+(b-=2));
        System.out.println("Division by 2: "+(a/=2));
        System.out.println("Mod Div by 2: "+(b%=2));
       
        
        
    }
}
