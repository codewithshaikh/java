
package Ifelse;

import java.util.*;
public class IfElse2 {
    
    public static void main(String args[])
    {
        Scanner scan = new Scanner(System.in);
        int a;
        System.out.println("Enter a Number between 1-12: ");
        a = scan.nextInt();
        
        if(a==1)
        {
            System.out.println("Month is January");
        }
        else if(a==2)
        {
            System.out.println("Month is February");
        }
        else if(a==3)
        {
            System.out.println("Month is March");
        }
        else if(a==4)
        {
            System.out.println("Month is April");
        }
        else if(a==5)
        {
            System.out.println("Month is May");
        }
        else if(a==6)
        {
            System.out.println("Month is June");
        }
        else if(a==7)
        {
            System.out.println("Month is July");
        }
        else if(a==8)
        {
            System.out.println("Month is August");
        }
        else if(a==9)
        {
            System.out.println("Month is September");
        }
        else if(a==10)
        {
            System.out.println("Month is October");
        }
        else if(a==11)
        {
            System.out.println("Month is November");
        }
        else 
        {
            System.out.println("Month is December");
        }
    }
}
