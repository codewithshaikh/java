package Ifelse;
import java.util.*;
public class Marksheet {
    
    public static void main(String ags[])
    {
        Scanner scan = new Scanner(System.in);
        
        String name ;
        
        char div ;
        int eng ,che,phy,maths,cs1,cs2,tot , std , roll;
        float per ;
        
        System.out.println("Enter Your Name:- ");
        name = scan.nextLine();      // For Full Name With Space
        
        System.out.println("Enter Your Std: ");
        std = scan.nextInt();
        
        System.out.println("Enter Your Division :- ");
        div = scan.next(".").charAt(0);
        
        System.out.println("Enter Your Roll No: ");
        roll = scan.nextInt();
        
        System.out.println("Enter Your English Marks :- ");
        eng = scan.nextInt();
        
        System.out.println("Enter Your Physics Marks :- ");
        phy = scan.nextInt();
        
        System.out.println("Enter Your Chemistry Marks :- ");
        che = scan.nextInt();
        
        System.out.println("Enter Your Maths Marks :- ");
        maths = scan.nextInt();
        
        System.out.println("Enter Your CS-1 Marks :- ");
        cs1 = scan.nextInt();
        
        System.out.println("Enter Your CS-2 Marks :- ");
        cs2 = scan.nextInt();
        
        tot = eng + phy + che + maths + cs1 + cs2;
        per = tot/6;
        
        System.out.println("\n================================================\n");
        
        System.out.println("Name       : "+name);
        System.out.println("Standard   : "+std);
        System.out.println("Division   : "+div);
        System.out.println("\n================================================");
        System.out.println("\t\t Marks");
        System.out.println("================================================");
        System.out.println("English    : "+eng);
        System.out.println("Physics    : "+phy);
        System.out.println("Chemistry  : "+che);
        System.out.println("Maths      : "+maths);
        System.out.println("CS-1       : "+cs1);
        System.out.println("CS-2       : "+cs2);
        System.out.println("\n================================================\n");
        System.out.println("Total      : "+tot);
        System.out.println("Percentage : "+per+"%");
    }
}
