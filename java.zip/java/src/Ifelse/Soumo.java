package Ifelse;


public class Soumo {

    public static void main(String[] args) {
        System.out.print("Hello World \n");
        System.out.println("My Name is Soumodeep");
        System.out.println("Welcome to Java \nIt a Full Object Oriented Application ");
        System.out.print("Lets Learn Java \nGet Started\n");
        
        System.out.println("\n\nName  : Soumodeep Dutta");
        System.out.println("Standard  : 12th");
        System.out.println("Physics   : 095/100");
        System.out.println("Chemistry : 096/100");
        System.out.println("Maths     : 090/100");
        System.out.println("PEnglish  : 079/100");
        System.out.println("Computer  : 195/200");
        System.out.println("Percentage: 92.5%");
    }
    
   
    
}
