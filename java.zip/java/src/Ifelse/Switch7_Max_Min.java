package Ifelse;

import java.util.*;

public class Switch7_Max_Min {

    public static void main(String args[])
    {
        Scanner scan = new Scanner(System.in);
        int n1 , n2 , dec ;
        System.out.println("Enter First Number : ");
        n1 = scan.nextInt();
        
        System.out.println("Enter Second Number : ");
        n2 = scan.nextInt();
        
         
        switch(n1 > n2 ? 1 : 0)
        {
            case 1:
                System.out.println(n1+" is Maximum");
                break;
                
            case 0:
                
                switch(n2>n1 ? 1: 0)
                {
                    case 1:
                        System.out.println(n2+" is Maximum");
                        break;
                        
                    case 0:
                        System.out.println("Both are Equal");
                        break;
                        
                }
        }
    }
}
