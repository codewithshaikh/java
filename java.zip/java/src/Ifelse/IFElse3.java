
package Ifelse;

import java.util.*;
public class IFElse3 {
    
    public static void main(String args[])
    {
        Scanner scan = new Scanner(System.in);

        int a , b ,c;
        System.out.println("Enter 1st Number: ");
        a = scan.nextInt();
        System.out.println("Enter 2nd Number: ");
        b = scan.nextInt();
        System.out.println("Enter 3rd Number: ");
        c = scan.nextInt(); 
        if(a>b && a>c)
        {
            System.out.println(a+" is Greater");
        }
        else if(b>c && b>a)
        {
            System.out.println(b+" is Greater");
        }
        else if(a==b && b==c)
        {
            System.out.println("All are Same ");
        }
        else
        {
             System.out.println(c+" is Greater");
        }
    }
}
