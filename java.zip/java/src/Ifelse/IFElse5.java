package Ifelse;

import java.util.*;
public class IFElse5 {
    
    public static void main(String args[])
    {
        Scanner scan = new Scanner(System.in);
        int a;
        System.out.println("Enter Any Number: ");
        a = scan.nextInt();
        
        if(a%2==0)
        {
            System.out.println("Number is Even");
        }
        else
        {
            System.out.println("Number is Odd");
        }
    }
    
}
