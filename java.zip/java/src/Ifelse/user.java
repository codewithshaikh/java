
package Ifelse;
import java.util.*;
public class user {
    public static void main(String args[])
    {
//        Scanner sc=new Scanner(System.in);
//        int a;
//        char ch='a';
//        String name="Rahul";
//        float f=12.34f;
//        boolean b=true;
//        
//        int num;
//          System.out.print("Enter Any Number  :- ");
//          num=sc.nextInt();
//          System.out.println(num);
//          float num2;
//          System.out.print("Enter Float Number  :- ");
//          num2=sc.nextFloat();
//          System.out.println(num2);
//          
//          
//          String s;
//          System.out.print("Enter Name  :- ");
//          s=sc.next();
//          System.out.println(s);
//          
//          char c;
//          System.out.print("Enter Any character  :- ");
//          c=sc.next(".").charAt(0);
//          System.out.println(c);
        Scanner cc = new Scanner(System.in);
        
        int num1;
        System.out.println("Enter Any Number :- ");
        num1 =  cc.nextInt();
        System.out.println("Number is : - "+num1);
        
        float num2;
        System.out.println("Enter any Float Number :-");
         num2 = cc.nextFloat();
         System.out.println("Float Value is :- "+num2);
         
         //For String with Space
         String str;
         System.out.println("Enter Your String :- ");
         str= cc.nextLine();
         str=str+cc.nextLine();
         System.out.println("Your String is :- "+str);
         
         char ch;
         System.out.println("Enter Your Character :- ");
         ch = cc.next(".").charAt(0);
         System.out.println("Your Character is :- "+ch);
    }
}
