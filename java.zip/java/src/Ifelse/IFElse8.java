package Ifelse;

import java.util.*;
public class IFElse8 {
    
    public static void main(String args[])
    {
        Scanner scan = new Scanner(System.in);
        int cp , sp ;
        System.out.println("Enter the Cost Price : ");
        cp=scan.nextInt();
        System.out.println("Enter the Selling Price : ");
        sp=scan.nextInt();
        
        if(cp>sp)
        {
            System.out.println("You Occured an Loss of "+(cp-sp)+" Rupees");
        }
        else
        {
            System.out.println("You Occured an Profit of "+(sp-cp)+" Rupees");
        }
    }
    
}


