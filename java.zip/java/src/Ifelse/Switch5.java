
package Ifelse;

import java.util.*;
public class Switch5 {
    public static void main(String args[])
    {
        
//        Check Even or Odd using Switch Case
        
        Scanner scan = new Scanner(System.in);
        int a ;
        System.out.println("Enter the First Number: ");
        a = scan.nextInt();
        
        
       
        
        switch(a%2)
        {
            case 0 :
                System.out.println(a+" is an Even Number");
                break;
                
            case 1 :
                System.out.println(a+" is an Odd Number");
                break;
        }
    }
    
}
