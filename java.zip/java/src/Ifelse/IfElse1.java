package Ifelse;

import java.util.*;
public class IfElse1 {
    public static void main(String args[])
    {
        Scanner scan = new Scanner(System.in);
        int a;
        System.out.println("Enter a Number between 1-7: ");
        a = scan.nextInt();
        
        if(a==1)
        {
            System.out.println("Today is Sunday");
        }
        else if(a==2)
        {
            System.out.println("Today is Monday");
        }
        else if(a==3)
        {
            System.out.println("Today is Tuesday");
        }
        else if(a==4)
        {
            System.out.println("Today is Wednesday");
        }
        else if(a==5)
        {
            System.out.println("Today is Thursday");
        }
        else if(a==6)
        {
            System.out.println("Today is Friday");
        }
        else
        {
            System.out.println("Today is Saturday");
        }
    }
    
}
