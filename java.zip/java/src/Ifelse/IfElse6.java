package Ifelse;

import java.util.*;
public class IfElse6 {
    
    public static void main(String args[])
    {
        Scanner scan = new Scanner(System.in);
        int a;
        System.out.println("Enter Any Year: ");
        a = scan.nextInt();
        
        if(a%4==0 || a%400==0 && a%100!=0 )
        {
            System.out.println("Year is Leap Year");
        }
        else
        {
            System.out.println("Year is Not Leap Year");
        }
    }
    
}

