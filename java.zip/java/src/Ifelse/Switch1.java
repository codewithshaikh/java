
package Ifelse;

import java.util.*;
public class Switch1 {
  public static void main(String args[])
  {
      int num=2;
      
//      if(num==1)
//      {
//          System.out.println("One");
//      }
//      else if(num==2)
//      {
//          System.out.println("Two");
//      }
//      else if(num==3)
//      {
//          System.out.println("Three");
//      }
//      else
//      {
//          System.out.println("Invalid input");
//      }

        switch(num)
        {
            case 1:
                System.out.println("One");
                break;
                
            case 2:
                System.out.println("Two");
                break;
               
            case 3:
                System.out.println("Three");
                break;
                
            default:
                System.out.println("Invalid input");
                
        }
      
  }
}
