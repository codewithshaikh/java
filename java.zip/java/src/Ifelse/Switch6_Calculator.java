
package Ifelse;

import java.util.*;
public class Switch6_Calculator {
    public static void main(String args[])
    {
        
//        Check Even or Odd using Switch Case
        
        Scanner scan = new Scanner(System.in);
        int a ,b ,c;
        char symbol;
        
        System.out.println("Enter the First Number: ");
        a = scan.nextInt();
        
        System.out.println("Enter the First Number: ");
        b = scan.nextInt();
        
        System.out.println("Enter the Symbol[+ - / * %]: ");
        symbol = scan.next(".").charAt(0);
        
        
       
        
        switch(symbol)
        {
            case '+' :
                c = a + b;
                System.out.println("Addition is "+c);
                break;
                
            case '-' :
                c = a-b;
                System.out.println("Subtraction is "+c);
                break;
                
            case '*' :
                c = a*b;
                System.out.println("Multiplication is "+c);
                break;
                
            case '/' :
                c = a /b;
                System.out.println("Normal Division is "+c);
                break;
                
            case '%' :
                c = a % b;
                System.out.println("Modulo Division is "+c);
                break;
                
            default:
                System.out.println("Invalid Input");
        }
    }
    
}
