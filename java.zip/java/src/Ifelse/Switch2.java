
package Ifelse;

import java.util.*;
public class Switch2 {
    public static void main(String args[])
    {
//        Program to check Consonants and Vowels
        
        Scanner scan = new Scanner(System.in);
        
        char alphabet;
        System.out.println("Enter any Alphabet: ");
        alphabet = scan.next(".").charAt(0);
        
        switch(alphabet)
        {
            case 'a' :
            case 'e' :
            case 'i' :
            case 'o' :
            case 'u' :
                System.out.println("It is a Vowel");
                break;
                
            default:
                System.out.println("It is a Consonant");
        }
    }
}
