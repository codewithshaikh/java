package Ifelse;

/*
2) Write a program to input basic salary of an employee and calculate gross salary , pf=5% ,ma=10% , ecs=5% for each case and net salary form gross salary according to given conditions.
Basic Salary <= 10000 : HRA = 15%, DA = 20% , TA=25% .
Basic Salary is between 10001 to 20000 : HRA = 25%, DA = 30% , TA=35% .
Basic Salary >= 20001 : HRA = 35%, DA = 40% , TA=45% .
*/

import java.util.* ;
public class IFElse_Nested2 {
    public static void main(String args[])
    {
        System.out.println("\t\tSalary Slip");
        String name;
        int id;
        float bs , hra , da , ta , ma , gs , pf , ecs , net;
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Enter Employee Name: ");
        name = scan.nextLine();
        
        System.out.println("Enter Employee ID: ");
        id = scan.nextInt();
        
        System.out.println("Enter Your Basic Salary: ");
        bs = scan.nextFloat();
        
        if(bs<=10000.00)
        {
            hra = (float) (0.15*bs);
            da = (float)(0.20*bs);
            ta = (float)(0.25*bs);
            ma = (float)(0.1*bs);
            gs = bs + hra + da + ta + ma; 
            pf = (float)(0.05*gs);
            ecs = (float)(0.05*gs);
            net = gs -(pf+ecs);   
        }
        else if(bs>10000.00 && bs<=20000.00)
        {
            hra = (float) (0.25*bs);
            da = (float)(0.3*bs);
            ta = (float)(0.35*bs);
            ma = (float)(0.1*bs);
            gs = bs + hra + da + ta + ma;
            pf = (float)(0.05*gs);
            ecs = (float)(0.05*gs);
            net = gs -(pf+ecs);
        }
        else
        {
            hra = (float) (0.35*bs);
            da = (float)(0.4*bs);
            ta = (float)(0.45*bs);
            ma = (float)(0.1*bs);
            gs = bs + hra + da + ta + ma; 
            pf = (float)(0.05*gs);
            ecs = (float)(0.05*gs);
            net = gs -(pf+ecs);
        }
        
        System.out.println("\n\t\tSalary Slip\n");
        System.out.println("Name         : "+name);
        System.out.println("Id           : "+id);
        System.out.println("Basic Salary : "+bs);
        System.out.println("HRA          : "+hra);
        System.out.println("DA           : "+da);
        System.out.println("TA           : "+ta);
        System.out.println("MA           : "+ma);
        System.out.println("Gross Salary : "+gs);
        System.out.println("PF           : "+pf);
        System.out.println("ECS          : "+ecs);
        System.out.println("Net Salary   : "+net);
    }
}
