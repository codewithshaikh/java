
package Date_Time;

import java.time.LocalDate;
public class Date1 {
    public static void main(String[] args) {
        LocalDate myObj = LocalDate.now();
        System.out.println(myObj);
    }
}
