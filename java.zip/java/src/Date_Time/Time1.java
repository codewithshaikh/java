package Date_Time;

import java.time.LocalTime; // import the LocalTime class

public class Time1 {
  public static void main(String[] args) {
    LocalTime myObj = LocalTime.now();
    System.out.println(myObj);
  }
}
