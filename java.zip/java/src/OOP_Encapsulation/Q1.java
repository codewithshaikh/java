package OOP_Encapsulation;

import java.util.*;
class find{
    
    Scanner scan = new Scanner(System.in);
    private int num , t , f=1, i;
    
    
    public void getdata()
    {
        System.out.println("Enter a Number : ");
        num = scan.nextInt();
    }
    
    public void table()
    {
        for(int i=1 ; i<=10 ; i++)
        {
            t=num*i;
            System.out.println(num + " x " + i + " = " + t);
        }
    }
    
    public void factorial()
    {
        for(i=1 ; i<=num ;i++)
        {
            f = f*i;
        }
        System.out.println("Factorial is : "+ f);
    }
}

public class Q1 {
    public static void main(String[] args) {
        find obj = new find();
        obj.getdata();
        obj.table();
        obj.factorial();
    }
}
