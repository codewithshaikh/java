package Recursion_functions;

import java.util.*;

public class Recursion3 {
    public static int reverse(int num , int rev)
    {
        if(num==0)
        {
            return rev;
        }
        else
        {
            return reverse(num/10 , rev*10+num%10);
        }
    }
    
    public static void main(String args[])
    {
        int num , result;
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter a Number : ");
        num  = scan.nextInt();
        result = reverse(num , 0);
        System.out.println("Reverse : " + result);
    }
}
