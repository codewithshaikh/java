package Recursion_functions;

import java.util.*;

public class Recursion2 {
    public static int LCM(int a , int b , int m)
    {
        
        if((m%a==0) && (m%b==0))
        {
            return m;
        }
        else
        {
            m++;
            return LCM(a , b , m);
        }
    }
    
    public static void main(String args[])
    {
        Scanner scan = new Scanner(System.in);
        int a , b ;
        System.out.println("Enter Two Numbers: ");
        a =  scan.nextInt();
        b = scan.nextInt();
        int result = LCM(a,b,1);
        System.out.println("LCM : "+result);
    }
    
}

    