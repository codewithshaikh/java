package Recursion_functions;
 
// GCD  function

public class Recursion1 {
    public static int GCD(int a , int b)
    {
        if(a>b)
        {
            return GCD(a-b , b);
        }
        else if(a<b)
        {
            return GCD(a , b-a);
        }
        else
        {
            return a;
        }
       
      
    }
    
    
    public static void main(String args[])
    {
        int a = 10 , b = 4;
        int res = GCD(a , b );
        System.out.println("Result : " + res);
    }
}
