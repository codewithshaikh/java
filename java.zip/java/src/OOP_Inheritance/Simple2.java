package OOP_Inheritance;
   
import OOP_Class.*;
import java.util.*;

    //To check even or odd and prime or not

class data{
    
    Scanner scan = new Scanner(System.in);
    protected int num;
    
    void getdata()
    {
        System.out.println("Enter a Number : ");
        num = scan.nextInt();
    } 
}

class check extends data
{
    int i , c = 0;
    void prime()
    {
        for(i=2 ; i<num ; i++)
        {
            if(num%i==0)
            {
                System.out.println("It is not a prime Number ");
                c=1;
                break;
            }
        }
        
        if(c==0)
        {
            System.out.println("It is a Prime Number ");
        }
    }
    void eo()
    {
        if(num%2==0 )
        {
            System.out.println("It is an Even Number");
        }
        else
        {
            System.out.println("It is an Odd Number ");
        }
    }
}

public class Simple2 {
    public static void main(String[] args) {
        check obj = new check();
        obj.getdata();
        obj.eo();
        obj.prime();
    }
}
