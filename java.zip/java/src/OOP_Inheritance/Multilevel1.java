package OOP_Inheritance;
import OOP_Class.*;
import java.util.*;

class num1{
    Scanner scan = new Scanner(System.in);
    protected int a;
    void getdata()
    {
        System.out.println("Enter first Number ");
        a =  scan.nextInt();
    }
}


class num2 extends num1{
    Scanner scans = new Scanner(System.in);
    protected int b ;
    void getdata1()
    {
        System.out.println("Enter first Number ");
        b =  scans.nextInt();
    }
}

public class Multilevel1 extends num2{
    public static void main(String[] args) {
        Multilevel1 c = new Multilevel1();
        c.getdata();
        c.getdata1();
        System.out.println("Addition is : "+ (c.a + c.b));
        System.out.println("Subtraction is : "+ (c.a - c.b));
        System.out.println("Multiplication is : "+ (c.a * c.b));
        System.out.println("Division is : "+ (c.a / c.b));
                
    }
}

