package OOP_Inheritance;

class student{
    
    void name()
    {
        System.out.print(" The method of the class Student invoked.");
    }
}

class science extends student
{
    void name1()
    {
        System.out.print(" The method of the class Science invoked.");
    }
}


class commerce extends student
{
    void name2()
    {
        System.out.print(" The method of the class Commerce invoked.");
    }
}


class arts extends student
{
    void name3()
    {
        System.out.print(" The method of the class arts invoked.");
    }
}

public class Hierarchical2 {
    
    public static void main(String[] args) {
        science s = new science();
        commerce m = new commerce();
        arts a =  new arts();
        
        
        // calls student class method
        s.name(); System.out.print( " by science class object\n ");
        m.name(); System.out.print( " by commerce class object\n ");
        a.name(); System.out.print( " by arts class object\n\n\n  ");
        
        
        
        // calls science  commerce and arts class by own objects
        
        s.name1();  System.out.print( " by science class object\n ");
        m.name2();  System.out.print( " by commerce class object\n ");
        a.name3();  System.out.print( " by arts class object\n ");
    }
    
}
