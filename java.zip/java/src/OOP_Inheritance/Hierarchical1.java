package OOP_Inheritance;

class Animal
{
    void sound()
    {
        System.out.println("It is an Sound Method of Animal Class (Parent Class)");
    }
}

class dog extends Animal
{
    void bark()
    {
        System.out.println("Dog Barks");
    }
}

class cat extends Animal{
    
    void meow()
    {
        System.out.println("Cat Meows ");
    }
}

class monkey extends Animal
{
    void screech()
    {
        System.out.println("Monkey Screeches");
    }
}

public class Hierarchical1 {
    
    public static void main(String[] args) {
        dog d = new dog();
        cat c = new cat();
        monkey m = new monkey();
        
        d.sound();
        d.bark();
        
        c.sound();
        c.meow();
        
        m.sound();
        m.screech();
    }
    
}
