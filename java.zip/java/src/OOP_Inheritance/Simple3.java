package OOP_Inheritance;
   
import OOP_Class.*;
import java.util.*;

    //To find factorial and table

class datas{
    
    Scanner scan = new Scanner(System.in);
    protected int num;
    
    void getdata()
    {
        System.out.println("Enter a Number : ");
        num = scan.nextInt();
    } 
}

class find extends datas
{
    int i , f = 1;
    int factorial()
    {
        for(i=1 ; i<=num ; i++)
        {
            f =f *i;
        }
        return f;
    }
    void table()
    {
        int i , t ;
        for(i=1 ; i<=10 ; i++)
        {
            t =  i*num;
            System.out.println(num + " x " + i + " = " + t);
        }
    }
}

public class Simple3 {
    public static void main(String[] args) {
        find obj = new find();
        obj.getdata();
        int fac = obj.factorial();
        System.out.println("Factorial is  " + fac + "\n\nTable is : ");
        obj.table();
    }
}

