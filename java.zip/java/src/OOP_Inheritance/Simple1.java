package OOP_Inheritance;

class car{
    
    protected String brand = "Ford";
    void cars()
    {
        System.out.println("Hello, Welcome o car Shop");
    }
}

public class Simple1 extends car{
    public String name = "Mustang";
    public static void main(String[] args) {
        Simple1 c = new Simple1();
        c.cars();
        System.out.println(c.brand + " "+ c.name );
                
    }
}
