package Functions;

import java.util.*;

public class Functions {
    public static void greet() //no argumentrs with no return values
    {
        System.out.println("Good Mornning");
    }
    
    public static void sum(int a,int b)
    {
        System.out.println("Sum is "+(a+b));
    }
    
    public static int getError()
    {
        return 456;
    }
    
    public static int getSum(int a,int b)
    {
        return a+b;
    }
    
    public static void main(String args[])
    {
        greet();
        sum(2,3);
        int ans=getSum(4,5);
        System.out.println(ans);
        System.out.println(getError());
        
    }
}
