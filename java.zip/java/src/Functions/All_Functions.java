
package Functions;
 
import java.util.*;
public class All_Functions {
    
    public static void armCheck(int num)
    {
        System.out.println("Welcome to Armstrong Number Check \n");
        int d , value=0 , temp=num ;
        while(temp!=0)
        {
            d = temp % 10 ;
            value = value + ( d * d * d);
            temp = temp/10;
        }
        
        if(num == value)
        {
            System.out.println("It is an Armstrong Number ");
        }
        else
        {
            System.out.println("It is not an Armstrong Number ");
        }
    }
    
    
    
    public static void palindromeCheck(int num)
    {
        System.out.println("Welcome to Palindrome Number Check \n");
        int d , r = 0 , temp = num ;
        
        while(temp!=0)
        {
            d = temp % 10 ;
            r = r + ( d * d * d);
            temp = temp/10;
        }
        
        if(num == r)
        {
            System.out.println("It is an Armstrong Number ");
        }
        else
        {
            System.out.println("It is not an Armstrong Number ");
        }
    }
    
    
    public static void armRange(int fst , int lst)
    {
        System.out.println("Welcome to Armstrong Number in Range \n");
        int d , value=0 ;
        
        for( int temp = fst  ; temp< lst ; temp++)
        {
            value = 0;
            for(int i = temp ;  i!=0 ; i = i /10)
            { 
                d = i % 10 ;
                value = value + ( d * d * d);
            }
            
            if(temp == value)
            {
                System.out.println(temp);
            }
            
            
        }
    }
    
    
    
    public static void palindromeRange(int fst , int lst)
    {
        System.out.println("Welcome to Palindrome  Number in Range \n");
        int d , r=0 ;
        
        for( int num = fst  ; num < lst ; num ++)
        {
            r = 0;
            for(int i = num ;  i!=0 ; i = i /10)
            { 
                d = i % 10 ;
                r = (r*10) + d;
            }
            
            if(num == r)
            {
                System.out.println(num);
            }
            
        }
    }
    
    public static void primeCheck(int num)
    {
        System.out.println("Welcome to Prime NumberCheck \n");
        int c =0 ;
        for(int i = 2 ; i<num ; i++)
        {
            if(num%i==0)
            {
                c++;
                System.out.println("Not a Prime Number");
                break;
            }
        }
        
        if(c==0)
        {
            System.out.println("It is a Prime Number ");
        }
    }
    
    public static void primeRange(int fst ,  int lst)
    {
        System.out.println("Welcome to Prime Number in Range \n");
        for(int i = fst ; i<lst ; i++)
        {
            int c=0;
            for(int j = 2 ; j<i ; j++)
            {
                if(i%j==0)
                {
                    c++;
                    break;
                }
            }
            if(c==0)
            {
                System.out.println(i);
            }
        }
    }
    
    public static void spyCheck(int num)
    {
        System.out.println("Welcome to Spy Number Check \n");
        int d , sum =0 , p=1 ;
        while(num!=0)
        {
            d = num % 10 ;
            sum = sum + d;
            p = p * d;
            num = num /10; 
        }
        
        if(sum == p)
        {
            System.out.println("It is an Spy Number ");
        }
        else
        {
            System.out.println("It is not an Armstrong Number ");
        }
    }
    
    
    public static void spyRange(int fst , int lst)
    {
        System.out.println("Welcome to Armstrong Number in Range \n");
        int d ,  s = 0 , p = 1 ;
        
        for( int num = fst  ; num < lst ; num ++)
        {
            s = 0;
            p = 1;
            for(int i = num ;  i!=0 ; i = i /10)
            { 
                d = i % 10 ;
                s = s + d;
                p = p * d;
            }
            
            if(s == p)
            {
                System.out.println(num);
            }  
        }
    }
    
    public static void main(String args[])
    {
        
//       We have Following functions for Checking
//       1)armCheck(int num) , palindromeCheck(int num), primeCheck(int num) , spyCheck(int num)
//       
//       We have Following functions for finding in Range
//       1)armRange(int i , int j) , palindromeRange(int i , int j), primeRange(int i , int j) , spyRange(int i , int j)
//       
       
    }
    
}
