
package  FUnctions;

public class Recurrsion {
//    public static void Series(int num)
//    {
//        System.out.println(num);
//        num++;
//        if(num<=5)
//        {
//            Series(num);
//            
//        }
//    }
    
    public static void Series(int num)
    {
        num++;
        if(num<5 )
        {
            
            Series(num);
            
        }
        System.out.println(num);
        
        
    }
    public static void main(String args[])
    {
        Series(0);
    }
}
