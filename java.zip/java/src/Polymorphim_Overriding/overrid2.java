
package Polymorphim_Overriding;

class Animal {
   protected void displayInfo() 
   {
      System.out.println("I am an animal.");
   }
}

class Dog extends Animal {
   public void displayInfo() 
   {
      System.out.println("I am a bird.");
      super.displayInfo();  // This super keyword calls the parent class override function . super cannot be used in main class 
   }
//   void only()
//   {
//        super.displayInfo();
//   }
}


public class overrid2 
{
    public static void main(String[] args) 
    {
      Dog d1 = new Dog();
      d1.displayInfo();
//      d1.only();
     
   }
}
