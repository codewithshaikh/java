package ArrayList;

/*  To modify an element, use the set() method and refer to the index number  */

import java.util.*;

public class Code3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
    
        ArrayList<Integer> cars =  new ArrayList<>();
            
        int i,  n , num , index , value;
        System.out.println("Enter no of Items U want : ");
        n = sc.nextInt();
        
        
        
        for(i=0 ; i<n ; i++)
        {
            num = sc.nextInt();
            cars.add(i,num);
        }
        
        System.out.println("\nArrayList : " + cars);
        System.out.println("Enter index Number u want to change : ");
        index = sc.nextInt();
        System.out.println("Enter value u want to change : ");
        value = sc.nextInt();
        
        cars.set(index-1, value);
        
        System.out.println("Change ArrayList : "+cars);
    }
            
}
