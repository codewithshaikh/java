package ArrayList;
/*Printing array By For Each Loop*/

import java.util.ArrayList;

public class Code5 {
  public static void main(String[] args) 
  {
        ArrayList<Integer> array_Numbers = new ArrayList<Integer>();
        array_Numbers.add(10);
        array_Numbers.add(15);
        array_Numbers.add(20);
        array_Numbers.add(25);
        for (int i : array_Numbers) {
          System.out.println(i);
        }
  }
}
