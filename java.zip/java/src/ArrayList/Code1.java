package ArrayList;
/*  To Create and Add and Print Array Items*/

//import ArrayList Class or util whole package;
//import java.util.ArrayList; 

/*  Or */

import java.util.*;

public class Code1 
{
    public static void main(String[] args) 
    {
        ArrayList<Integer> array = new ArrayList<Integer>();
        
        array.add(44);
        array.add(10);
        array.add(4);
        array.add(20);
        array.add(100);
        
        System.out.println(array);
        
    }
}
