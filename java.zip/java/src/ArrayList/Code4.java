package ArrayList;

/*  To remove an element, use the remove() method and refer to the index number */
import java.util.*;   //(Includes ArrayList and Scanner Class)


public class Code4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
    
        ArrayList<Integer> cars =  new ArrayList<>();
            
        int i,  n , num , index;
        System.out.println("Enter no of Items U want : ");
        n = sc.nextInt();
        
        
        
        for(i=0 ; i<n ; i++)
        {
            num = sc.nextInt();
            cars.add(i,num);
        }
        
        System.out.println("\nArrayList : " + cars);
        System.out.println("Enter index Number u want to remove : ");
        index = sc.nextInt();
        
        
        cars.remove(index-1);
        
        System.out.println("Change ArrayList : "+cars);
        
        //To remove all the elements in the ArrayList, use the clear() method
        //To find out how many elements an ArrayList have, use the size method
    }
}
