package ArrayList;

/*  Sort an ArrayList   */

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Collections;

public class Code6 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
    
        ArrayList<Integer> nums =  new ArrayList<>();
            
        int i,  n , num , index;
        System.out.println("Enter no of Items U want : ");
        n = sc.nextInt();
        
        
        
        for(i=0 ; i<n ; i++)
        {
            num = sc.nextInt();
            nums.add(i,num);
        }
        
        System.out.println("\nArrayList Before Sorting : " + nums);
        
        Collections.sort(nums);
        
         System.out.println("\nArrayList After Sorting : " + nums);
    }
}
