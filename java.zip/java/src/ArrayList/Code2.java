package ArrayList;

/*To Get User Input and print ArrayLIst Elements using */

import java.util.*;

public class Code2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
    
        ArrayList<String> cars =  new ArrayList<String>();
            
        String str;
        int i,  n ;
        System.out.println("Enter no of Items U want : ");
        n = sc.nextInt();
        
        
        
        for(i=0 ; i<n ; i++)
        {
            str = sc.next();
            cars.add(i,str);
        }
        
        System.out.println("\nArrayList : " + cars +"\nArrayList by Get method: ");
        for(i=0 ; i<n ; i++)
        {
            System.out.print(cars.get(i) + " , ");
        }
    }
}
