package Array;

import java.util.*;

public class Array3 {
    public static void main(String args[])
    {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter the Size of Array: ");
        int size = scan.nextInt();
        int arr[] = new int[size];
        System.out.println("Enter "+size+" Elements : ");
        for(int i=0 ; i<arr.length; i++)
        {
            arr[i] = scan.nextInt();
        }
       
        
        for(int i=0 ; i<arr.length ; i++)
        {
           for(int j=i+1 ; j<arr.length ; j++)
           {
               if(arr[i]>arr[j])
               {
                   int temp = arr[j];
                   arr[j] = arr[i];
                   arr[i] = temp;
               }
           }
        }
        
//        System.out.println("First Smallest : "+min1);
//        System.out.println("Second Smallest: "+min2);
     
                
        System.out.println("\nElements in Ascending Order are : ");
        for(int i=0 ; i<arr.length ; i++)
        {
            System.out.println(arr[i]);
        }
    }
}
