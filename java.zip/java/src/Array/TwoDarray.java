package Array;

import java.util.*;
public class TwoDarray {
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        //int mat[][]={{1,2,3},{4,5,6},{7,8,9}};
//        int mat[][]=new int[3][3];
        System.out.println("Enter No. of rows :- ");
        int row=sc.nextInt();
        System.out.println("Enter No. of cols :- ");
        int col=sc.nextInt();
        int mat[][]=new int[row][col];
        System.out.println("Enter values for matrix :-");
        for(int i=0;i<row;i++)
        {
            for(int j=0;j<col;j++)
            {
                System.out.print((i+1)+" Row "+(j+1)+" col :- ");
                mat[i][j]=sc.nextInt();
            }
        }
        
        System.out.println("\nEntered Matrix is :- ");
        for(int i=0;i<row;i++)
        {
            for(int j=0;j<col;j++)
            {
                System.out.print(mat[i][j]+" ");
            }
            System.out.println();
        }
    }
}
