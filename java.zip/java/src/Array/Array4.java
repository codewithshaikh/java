package Array;

import java.util.*;

public class Array4 {
    public static void main(String args[])
    {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter the Size of Array: ");
        int size = scan.nextInt();
        int arr[] = new int[size];
        System.out.println("Enter "+size+" Elements : ");
        for(int i=0 ; i<arr.length; i++)
        {
            arr[i] = scan.nextInt();
        }
        
        int min1= arr[0] , min2= arr[1];
        if(min1>min2)
        {
            int temp = min2;
            min2 = min1;
            min1 = temp;
        }
        
        for(int i=2 ; i<arr.length ; i++)
        {
            if(min1>arr[i])
            {
                min2 = min1;
                min1 = arr[i];
            }
            else if(min2>arr[i])
            {
                min2 = arr[i];
            }
        }
        
        System.out.println("First Smallest : "+min1);
        System.out.println("Second Smallest: "+min2);
     
                
//        System.out.println("\nElements are : ");
//        for(int i=0 ; i<arr.length ; i++)
//        {
//            System.out.println(arr[i]);
//        }
    }
}
