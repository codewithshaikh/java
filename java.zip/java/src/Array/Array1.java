
package Array;

import java.util.*;
public class Array1 {
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
//        int arr[]={10,20,3,4,5,6};
//        int arr[]=new int[5];
        System.out.println("Enter The Size of Array :- ");
        int size=sc.nextInt();
        int arr[]=new int[size];
//        System.out.println(arr.length);
        for(int i=0;i<arr.length;i++)
        {
            arr[i]=sc.nextInt();
        }
        System.out.println("Entered Values are :- ");
        for(int i=0;i<arr.length;i++)
        {
            System.out.println(arr[i]);
        }
    }
}
