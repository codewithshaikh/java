package Array;
import java.util.*;
public class Array2 {
    public static void main(String args[])
    {
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Enter the Size of Array: ");
        int size = scan.nextInt();
        
        int arr[] = new int[size] ;
        
        System.out.println("Enter "+size+" Elements : ");
        for(int i=0 ; i<arr.length ; i++)
        {
            arr[i] = scan.nextInt(); 
        }
        
        System.out.println("Elementss : ");
        for(int i =0 ; i<arr.length ; i++)
        {
            System.out.println(arr[i]);  
        }
        
        int max1= arr[0] , max2=arr[1];
        if(max1<max2)
        {
            int temp = max1;
            max1= max2;
            max2=temp;
        }
        for(int i=2; i<arr.length; i++)
        {
            if(max1<arr[i])
            {
                max2=max1;
                max1=arr[i];
           
            }
            else if(max2<arr[i])
            {
                max2=arr[i];
            }
        }
        
        System.out.println("First Largest: "+max1);
        System.out.println("Second Largest : "+max2);
    }
    
}
