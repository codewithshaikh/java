package OOP_Constructor;

import OOP_Class.*;
import java.util.*;

class num{
        Scanner scan = new Scanner(System.in);
    
    int num , t , i , f = 1;
    num()
    {
        System.out.println("Enter a  Number: ");
        num = scan.nextInt();
    }
    void table()
    {
        System.out.println("Table of " +num +" is : ");
        for(i=0 ; i<=10 ; i++)
        {
            t = num*i;
            System.out.println(num + " x "+ i + " = "+ t);
        }
    }
    
    int  factorial()
    {
        for(i=1 ; i<=num ; i++)
        {
            f = f*i;
        }
        return f;
    }
}
public class Simple2 {
    public static void main(String[] args) {
        num n = new num();
        n.table();
        System.out.println("Factorial is " + n.factorial());
    }
}
