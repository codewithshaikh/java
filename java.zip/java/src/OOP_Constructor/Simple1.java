package OOP_Constructor;
import OOP_Class.*;
import java.util.*;

class add{
    Scanner scan = new Scanner(System.in);
    int a  , b ;
    add()
    {
        System.out.println("Enter two Numbers : ");
        a = scan.nextInt();
        b =  scan.nextInt();
    }
    void print()
    {
        System.out.println(" Addition of two Numbers by constructor is : "+(a+b));
    } 
}

class minus
{
    Scanner scan = new Scanner(System.in);
    int a , b;
    minus()
    {
        System.out.println("Enter two Numbers : ");
        a = scan.nextInt();
        b = scan.nextInt();
    }
    
    void prints()
    {
        System.out.println("Subtraction of two Numbers by constructor is : "+(a-b));
    }
}
public class Simple1 {
    public static void main(String[] args) {
        add a = new add();
        a.print();
        
        minus m = new minus();
        m.prints();
    }
}
