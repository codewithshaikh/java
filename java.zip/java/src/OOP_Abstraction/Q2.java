/*
Question : Create an abstract class 'Parent' with a method 'message'. It has two subclasses each having a method 
            with the same name 'message' that prints "This is first subclass" and "This is second subclass" respectively. 
            Call the methods 'message' by creating an object for each subclass.
 */
package OOP_Abstraction;

abstract class Parent{
    public abstract void message();
}

class sub1 extends Parent{
    public void message()
    {
        System.out.println("This is First SubClass Message Function");
    }
}

class sub2 extends Parent{
    public void message()
    {
        System.out.println("This is Second Subclass Message Function");
    }
}
public class Q2 {
    public static void main(String[] args) {
        sub1 obj1 = new sub1();
        sub2 obj2 = new sub2();
        obj1.message();
        obj2.message();
    }
}
