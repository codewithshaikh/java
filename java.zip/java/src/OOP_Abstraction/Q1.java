package OOP_Abstraction;
abstract class Animal{
 public abstract void animalSound();
    
    void sleep()
    {
        System.out.println("Sleep Function of abstract class");
    }
}


class dog extends Animal{
     @Override
     public void animalSound() {
    System.out.println("The dog says: bho bho");
  }
    
     @Override
     void sleep()
    {
        System.out.println("Sleep Function of dog class");
        super.sleep();
    }
}
public class Q1 {
    public static void main(String[] args) 
    {
        dog my = new dog(); // Create a dog object
        my.animalSound();
        my.sleep();
  }
}
