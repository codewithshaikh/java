/*
Question : Create an abstract class 'Bank' with an abstract method 'getBalance'. $100, $150 and $200 are deposited in banks 
A, B and C respectively. 'BankA', 'BankB' and 'BankC' are subclasses of class 'Bank', each having a method named 'getBalance'. 
Call this method by creating an object of each of the three classes
 */
package OOP_Abstraction;

abstract class Bank{
    public abstract void getBalance();
}

class BankA extends Bank{
    public void getBalance()
    {
        System.out.println("Peron has Deposited $100 Balance in BankA Has $100 Balance");
    }
}

class BankB extends Bank{
    public void getBalance()
    {
        System.out.println("Peron has Deposited $150 Balance in BankB ");
    }
}

class BankC extends Bank{
    public void getBalance()
    {
        System.out.println("Peron has Deposited $200 Balance in BankC");
    }
}
public class Q3 {
    public static void main(String[] args) {
        BankA A = new BankA();
        BankB B = new BankB();
        BankC C = new BankC();
        A.getBalance();
        B.getBalance();
        C.getBalance();
    }
}
