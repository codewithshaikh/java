package String;

/* String Concatenation */
public class String3 {
    public static void main(String[] args) {
        
        String first = "Karan ";
        String last = "Sharma";
        
        //Method-1
        System.out.println("String ConCatenation Method-1: " + first  + last);
        
        
        //Method-2
        System.out.println("String ConCatenation Method-2: "+first.concat(last));
    }
}
