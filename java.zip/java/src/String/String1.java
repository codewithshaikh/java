package String;

/*String Length and UpperCase and Lowercase*/

public class String1 {
    public static void main(String[] args) {
        String str = "This is a Demo String";
        System.out.println("String : "+str);
        
        
        //Length of String
        int len = str.length();
        System.out.println("Length of String (Counted With  Spaces): "+ len);
        
        
        //UpperCase and LowerCase
        System.out.println("String in UpperCase : " + str.toUpperCase());   // Outputs "HELLO WORLD"
        System.out.println("String in LowererCase  : " +str.toLowerCase());
    }
}
