package String;

import java.util.*;

/* To Check String is Palindrome or Not */

public class String8 {
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        String str ;
        int i , flag =0  , len  ;
        System.out.println("Enter Your String : ");
        str =  sc.nextLine();
        len = str.length();
        
        char s[] = str.toCharArray();
        for( i=0; i<len ; i++)
        {
            if(s[i] != s[len-i-1])
            {
                flag = 1;
                break;
            }  
        }
        
        if(flag ==1)
        {
            System.out.println("String is Not Palindrome");
        }
        else{
            System.out.println("String is Palindrome");
        }
     }
}

