package String;

/*  Question  : Count and print total no of consonants and vowels in user input string  */

import java.util.*;


public class String6 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str ;
        int i , words = 1 ;
        System.out.println("Enter Your String : ");
        str =  sc.nextLine();
        char s[] = str.toCharArray();
        for( i=0; i<str.length() ; i++)
        {
            if(s[i] == ' ')
            {
                words = words + 1;
            }
            
            
           
        }
        System.out.println("Total no of Words : " + words);
        
        }
}

