package String;
import java.util.*;

/* To find total number of alphabets digits and symbols */

public class String5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str ;
        int i , ch =0 , sym = 0 , num = 0 ;
        System.out.println("Enter Your String : ");
        str =  sc.nextLine();
        char s[] = str.toCharArray();
        for( i=0; i<str.length() ; i++)
        {
            if((s[i]>='a' && s[i]<='z') || (s[i]>='A' && s[i]<='Z') )
            {
                ch = ch + 1;
            }
            else if(s[i]>='0' && s[i]<='9')
            {
                num = num+1;
            }
            else
            {
                sym = sym+1;
            }
        }
        System.out.println("Total Alphabets : " + ch);
        System.out.println("Total Numbers   : "+ num);
        System.out.println("Total Symbols   : "+sym);
        
        }
}
