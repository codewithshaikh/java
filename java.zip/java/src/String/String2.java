package String;

import java.util.*;

/* String Toggle */

public class String2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str;
        int i;
        System.out.println("Enter Your String : ");
        str =  sc.nextLine();
        char s[] = str.toCharArray();
        for( i=0; i<str.length() ; i++)
        {
            if(s[i]>='a' && s[i]<='z')
            {
                s[i] = (char) (s[i] - 32);
            }
            else if(s[i]>='A' && s[i]<='Z')
            {
                s[i] = (char) (s[i] + 32);
            }
        }
        
        System.out.println("The toggled string is :-");
        
        //Method 1
//	for(i =0 ; i<s.length ; i++)
//        {
//            System.out.print(s[i]);
//         }
        
        
        //method -2
    	
        str = new String(s);
        System.out.println(str);
        }
        
    }
 
