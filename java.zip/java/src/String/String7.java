package String;

import java.util.*;

/* To Print String in Reverse Order */

public class String7 {
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        String str ;
        int i  ;
        System.out.println("Enter Your String : ");
        str =  sc.nextLine();
        
        System.out.println("Orginal String : "+ str);
        
        char s[] = str.toCharArray();
        
        System.out.print("Reverse String : ");
        
        for( i=str.length()-1  ; i>=0 ; i--)
        {
           System.out.print(s[i]);
        }
        System.out.println();
     }
}

