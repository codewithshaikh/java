package String;

/* String Comparison */

public class String4 {
    public static void main(String[] args) {
        
        String str1 = "Karan";
        String str2 = "Karan";
        String str3 = "Yadav";
        
        //Method-1
        System.out.println("String Comparison Method-1: " + str1.equals(str3));
        //For Ignore Case use first.equals.IgnoreCase(last);
        
    }   
}

