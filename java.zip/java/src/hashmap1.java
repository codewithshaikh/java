
import java.util.*;
public class hashmap1 {
    public static void main(String[] args) {
        HashMap<String , String > capitals = new HashMap();
        
        capitals.put("India","Delhi");
        capitals.put("Bangladesh" , "dhaka");
        capitals.put("England" , "London");
        capitals.put("Germany","Berlin");
        
        
        System.out.println("Item 1" + capitals.get("India"));
        
        System.out.println(capitals);
        
        
        capitals.remove("England");
        System.out.println(capitals);
        
        capitals.clear();
        System.out.println(capitals);
        
        
        int size = capitals.size();
        System.out.println("Size : " + size);
        
        
        for(String i : capitals.keySet())
        {
            System.out.println(i);
        }
        
        for(String j : capitals.values())
        {
            System.out.println(j);
        }
        
    }
}
