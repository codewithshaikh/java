
package FileIO;

import java.io.*;
import java.io.IOException;
import java.util.*;
public class Write {
    public static void main(String[] args) 
    {
        try{
            FileWriter Obj1 = new FileWriter("C://Users//Admin//Desktop//filename1.txt");
            Scanner sc = new Scanner(System.in);            
            String str ;
            System.out.println("Enter Any Text  : ");
            str = sc.nextLine();
            Obj1.write(str);
            Obj1.close();
            
        }
        catch(IOException e)
        {
            System.out.println("Error: - " + e.getMessage());
        }
        
    }
}