
package FileIO;

import java.io.*;
import java.io.IOException;
public class Create {
    public static void main(String[] args) 
    {
        try{
            File obj = new File("C://Users//Admin//Desktop//filename1.txt");
            if(obj.createNewFile())
            {
                System.out.println("File is Created");
            }
            else
            {
                System.out.println("File already Exists or Not Created");
            }
            
        }
        catch(IOException e)
        {
            System.out.println("Error: - " + e.getMessage());
        }
        
    }
}
