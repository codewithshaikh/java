
package FileIO;

import java.io.*;
import java.io.IOException;
import java.util.*;
public class Read {
    public static void main(String[] args) 
    {
        try{
            File Obj = new File("C://Users//Admin//Desktop//filename1.txt");
            Scanner reader = new Scanner(Obj);
          while(reader.hasNextLine())
          {
              String data = reader.nextLine();
            System.out.println(data);        
           }
            
        }
        catch(IOException e)
        {
            System.out.println("Error: - " + e.getMessage());
        }
        
    }
}