
package FileIO;

import java.io.*;
import java.io.IOException;
public class Get_Information {
    public static void main(String[] args) 
    {
        File obj = new File("C://Users//Admin//Desktop//filename1.txt");
        if(obj.exists())
        {
            System.out.println("File Name  : " + obj.getName());
            System.out.println("File Path  : " + obj.getAbsolutePath());
            System.out.println("Writeable: " + obj.canWrite());
            System.out.println("Readable :" + obj.canRead());
            System.out.println("File size in bytes :" + obj.length());
        }
        else
        {
            System.out.println("File doesnot Exists");
        }
        
    }
}
