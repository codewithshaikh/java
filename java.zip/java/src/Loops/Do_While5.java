
package Loops;

import java.util.*;
public class Do_While5 {
    public static void main(String args[])
    {
        // Printing First and Last Digit of a Number
     
        Scanner scan = new Scanner(System.in);
        int f ,l, n;
        System.out.println("Enter any Number: ");
         n = scan.nextInt();
        l = n%10;
         do{
             f = n%10;
             n=n/10;
         }while(n!=0);
         
         System.out.println("First Digit is "+f);
          System.out.println("Last Digit is "+l);
        
    }
}