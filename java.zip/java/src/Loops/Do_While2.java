/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Loops;

import java.util.*;
public class Do_While2 {
    
    public static void main(String args[])
    {
        // Print A to Z Alphabets
        
        char sym = 'a' , SYM = 'A';
        
        System.out.println("\nLowerCase Alphabets:");
        do{
            System.out.print(sym+"  ");
            sym++;
        }while(sym<='z');
        
        
        System.out.println("\n\nUpperCase Alphabets:");
        do{
            System.out.print(SYM+"  ");
            SYM++;
        }while(SYM<='Z');
    }
    
}
