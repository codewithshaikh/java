package Loops;

public class Do_While1 {
    public static void main(String args[])
    {
        // Print 1 to 10 Numbers
        int i = 1;
        do{
          System.out.println(i);  
          i++;
        }while(i<=10);
    }
}

