
package Loops;

import java.util.*;
public class Do_While3 {
    public static void main(String args[])
    {
        // Printing Table in Form (2 x 1 = 2)
     
        Scanner scan = new Scanner(System.in);
        int t , i = 1 , n;
        System.out.println("Enter any Number: ");
         n = scan.nextInt();
         
         System.out.println("Table of "+n+" is ");
         do{
             t=n*i;
             System.out.println(n+" x "+i+" = "+t);
             i++;
         }while(i<=12);
        
    }
}
