
package Loops;

import java.util.*;
public class Do_While6 {
    public static void main(String args[])
    {
        // Finding Sum of Digits of a Number and Reverse
     
        Scanner scan = new Scanner(System.in);
        int d,n , s= 0 , r =0;
        System.out.println("Enter any Number: ");
         n = scan.nextInt();
    
         do{
             d = n%10;
             s = s + d;
             r = (r*10)+d;
             n=n/10;
         }while(n!=0);
         
         System.out.println("Sum of Digits is "+s);
         System.out.println("Reverse of Digits is "+r);
        
    }
}