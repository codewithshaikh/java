
package Loops;

import java.util.*;
public class Do_While4 {
    public static void main(String args[])
    {
        // Printing Factorial of a Number
     
        Scanner scan = new Scanner(System.in);
        int f=1 ,i=1, n;
        System.out.println("Enter any Number: ");
         n = scan.nextInt();
        
         do{
             f=f*i;
             i++;
         }while(i<=n);
         
         System.out.println("Factorial of "+n+" is "+f);
        
    }
}