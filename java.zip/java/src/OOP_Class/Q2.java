package OOP_Class;

class car{
    
    protected String brand = "Ford";
    void cars()
    {
        System.out.println("Hello, Welcome o car Shop");
    }
}

public class Q2 extends car{
    public String name = "Mustang";
    public static void main(String[] args) {
        Q2 c = new Q2();
        c.cars();
        System.out.println(c.brand + " "+ c.name );
                
    }
}
