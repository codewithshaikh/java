package OOP_Class;
import java.util.*;

class sum{
    int a , b , c ;  
    void getdata1(int x , int y)
    {
        a = x ;
        b = y;
    }
    
    void putdata1()
    {
        c = a + b;
        System.out.println("Addition Value of  Sum Class is "+c);
    }
}

class sub{
    int a , b , c ;
    void getdata1(int x , int y)
    {
        a = x ;
        b = y;
    }
  
    void putdata1()
    {
        c = a - b;
        System.out.println("Subtraction Value of sub Class is "+ c);
    }
}
public class Q1 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int a ,b;
        System.out.println("Enter Two Numbers : ");
        a = scan.nextInt();
        b = scan.nextInt();

        sum s = new sum();
        s.getdata1(a,b);
        s.putdata1();


        sub n = new sub();
        n.getdata1(a,b);
        n.putdata1();
    }
}
