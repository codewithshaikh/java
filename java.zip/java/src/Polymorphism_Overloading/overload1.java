package Polymorphism_Overloading;

import java.util.Scanner;

class sum1{
    Scanner scan = new Scanner(System.in);
    void sum()
    {
        System.out.println("Enter Two Numbers : ");
        int a = scan.nextInt();
        int b = scan.nextInt();
        System.out.println("Sum by Input two Numbers and no parameter : "  + (a+b));
    }
    void sum(int a)
    {
        System.out.println("Sum by one default value 10 and one parameter 5 : "  + (a+10));
    }
    void sum(int a , int b)
    {
        System.out.println("Sum by both Parameters 5 and 25 : "  + (a+b));
    }
}

public class overload1 {
    
    public static void main(String[] args) {
        sum1 s = new sum1();
        s.sum();
        s.sum(5);
        s.sum(5,25);
    }
}
