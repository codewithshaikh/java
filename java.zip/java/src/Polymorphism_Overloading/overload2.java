/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Polymorphism_Overloading;

class student{
    void details()
    {
        System.out.println("Default Name , Roll no and Std");
        System.out.println("Name of Student : ABC" );
        System.out.println("Std : 9th");
        System.out.println("Roll Number : 15 \n");
    }
    
    void details(String name)
    {
        System.out.println("Default Roll no and Std");
        System.out.println("Name of Student : "+ name );
        System.out.println("Std :  11th");
        System.out.println("Roll Number : 25\n");
    }
    
    void details(String name, int std)
    {
        System.out.println("Default Roll no and Std");
        System.out.println("Name of Student : "+ name );
        System.out.println("Std : " + std + "th");
        System.out.println("Roll Number : 12\n");
    }
    
    void details(String name , int std , int roll)
    {
        System.out.println("Parameterized Name , Roll no and Std");
        System.out.println("Name of Student : "+ name );
        System.out.println("Std : " + std + "th");
        System.out.println("Roll Number : " + roll);
    }
    
}

public class overload2 {
    public static void main(String[] args) 
    {
        student stu = new student();
        stu.details();
        stu.details("EFGH");
        stu.details("IJKL" , 5);
        stu.details("MNOP",  7 , 55);
    }
}
