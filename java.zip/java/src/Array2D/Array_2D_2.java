
package Array2D;

import java.util.*;
public class Array_2D_2 {
    
    // Matrix Addition
    
    public static void main(String ags[])
    {
        Scanner scan = new Scanner(System.in);
        int row , col , i , j ;
        System.out.println("Enter no of Rows: ");
        row =  scan.nextInt();
        System.out.println("Enter no of Columns: ");
        col= scan.nextInt();
        int arr1[][] = new int[row][col];
        
        int arr2[][] = new int[row][col];
        
        int arr3[][] = new int[row][col];
        
        System.out.println("Enter "+(row*col)+" Elements of Matrix 1 ");
        for(i=0 ; i<row ; i++)
        {
            for(j=0 ; j<col ; j++)
            {
                arr1[i][j] = scan.nextInt();
            }
        }
        
        System.out.println("Enter "+(row*col)+" Elements of Matrix 2 ");
        for(i=0 ; i<row ; i++)
        {
            for(j=0 ; j<col ; j++)
            {
                arr2[i][j] = scan.nextInt();
            }
        }
        
        
        // Matrix Subtraction
        
        for(i=0 ; i<row ; i++)
        {
            for(j=0 ; j<col ; j++)
            {
                arr3[i][j] =  arr1[i][j] - arr2[i][j];
                
            }
        }
        
        // Matrix Printing
        
        System.out.println(" Matrix 1: ");
        for(i=0 ; i<row ; i++)
        {
            for(j=0 ; j<col ; j++)
            {
                System.out.print(arr1[i][j] +"  ");
            }
            System.out.println();
        }
        
        System.out.println(" Matrix 2 ");
        for(i=0 ; i<row ; i++)
        {
            for(j=0 ; j<col ; j++)
            {
               System.out.print(arr2[i][j] +"  ");
            }
            System.out.println();
        }
        
        System.out.println("Subtracted Matrix ");
        for(i=0 ; i<row ; i++)
        {
            for(j=0 ; j<col ; j++)
            {
                System.out.print(arr3[i][j] +"  ");
            }
            System.out.println();
        }
    }
    
}
