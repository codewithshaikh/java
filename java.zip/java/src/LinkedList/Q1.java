package LinkedList;

import java.util.LinkedList;

public class Q1 {
    public static void main(String[] args) {
     LinkedList<String> cars = new LinkedList<String>();
    cars.add("ab");
    cars.add("cd");
    cars.add("ef");
    cars.add("gh");
    System.out.println(cars);
    }
}
